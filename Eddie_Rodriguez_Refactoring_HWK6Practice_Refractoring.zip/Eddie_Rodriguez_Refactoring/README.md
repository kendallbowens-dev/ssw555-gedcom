# GEDCOM Refactoring Practice — Eddie Rodriguez, Group 2

Scope and Provenance

---

This package contains focused US07 and US21 modules, the Python unit-test cases,
and actual text output from running both versions. The modules are standalone
exercise extracts, not replacements for the complete team parser.

Source repository: https://github.com/kendallbowens-dev/ssw555-gedcom
Baseline commit: 9b7f914374fd4cd2dee70f7619968d97b22d2de3
US07 and shared helpers were extracted from gedcom\_parser.py. The initial 11 tests
were taken from test\_user\_stories.py. The US21 smelly version was deliberately
constructed by expanding the existing role loop into two duplicate branches,
as permitted by the assignment. All this is done not presented as historical 
GitHub code.


## Example 1 — Magic number (US07)

Before: the age check and error message repeat the literal 150.
After: MAX\_ALLOWED\_AGE names the threshold and supplies both the comparison
and the message. The rule still flags completed ages of 150 or more.
Technique: Replace Magic Number with Symbolic Constant.


## Example 2 — Duplicate code (US21)

Before: separate husband and wife blocks repeat lookup, comparison and message
construction. After: one loop uses role, field and expected-sex tuples.
Technique: Consolidate Duplicate Code using a parameterized loop.
Missing individuals are skipped, blank sex is shown as NA, and the husband
message still comes before the wife message.


## Automated test evidence

Both versions pass the same 15 tests: the repository's 11 original cases plus
four regression cases added for this exercise. The additional cases verify
exactly 150 at death, a living age over 150, blank-sex messages, and exact
message text/order when both spouse roles are incorrect. Running the expanded
suite on BOTH versions verifies that the refactoring preserves behavior.

No tests were removed or weakened. Output files contain real unit-test runs;
the assignment permits text output instead of screenshots.


## Run independently

From the smelly folder, run:
python -m unit-test -v test\_user\_stories.py
From the refactored folder, run the same command.
Use a separate command invocation for each folder so imports use the intended
local gedcom\_parser.py.


## Submission contents

* smelly/gedcom\_parser.py: original exercise code with both smells
* smelly/test\_user\_stories.py: automated tests
* smelly/test\_results.txt: passing before-refactoring output
* refactored/gedcom\_parser.py: cleaned code
* refactored/test\_user\_stories.py: automated tests including regression cases
* refactored/test\_results.txt: passing after-refactoring output
* refactoring.diff: exact code changes


Today's team commit refactored US05/US06 and US14. This package covers Eddie 
Rodriguez's US07/US21 separately. 

