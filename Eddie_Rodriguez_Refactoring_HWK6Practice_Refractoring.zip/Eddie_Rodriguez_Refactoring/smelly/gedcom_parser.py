# US07 and US21: focused before-refactoring exercise.
from datetime import date


def sort_key(record_id):
    i = len(record_id)
    while i > 0 and record_id[i - 1].isdigit():
        i -= 1
    prefix, digits = record_id[:i], record_id[i:]
    return (prefix, int(digits) if digits else 0)


def format_date(d):
    return d.strftime("%Y-%m-%d") if d else "NA"


def compute_age(birth, death):
    if not birth:
        return "NA"
    end = death if death else date.today()
    return end.year - birth.year - ((end.month, end.day) < (birth.month, birth.day))


def check_us07_less_than_150(individuals, today=None):
    # US07: a person's age should be less than 150 years.
    errors = []
    current_date = today if today is not None else date.today()
    for indi_id in sorted(individuals, key=sort_key):
        indi = individuals[indi_id]
        birth = indi["birth"]
        if not birth:
            continue
        end = indi["death"] if indi["death"] else current_date
        if compute_age(birth, end) >= 150:
            errors.append(
                f"ERROR: INDIVIDUAL: US07: {indi_id}: Age at "
                f"{'death' if indi['death'] else 'current date'} is 150 years or more "
                f"(birth {format_date(birth)}, end {format_date(end)})"
            )
    return errors


def check_us21_correct_gender(individuals, families):
    # Deliberately duplicated for this refactoring exercise.
    errors = []
    for fam_id in sorted(families, key=sort_key):
        fam = families[fam_id]
        husband_id = fam["husband"]
        husband = individuals.get(husband_id)
        if husband and husband["sex"] != "M":
            errors.append(
                f"ERROR: FAMILY: US21: {fam_id}: HUSB {husband_id} "
                f"has SEX {husband['sex'] or 'NA'}, expected M"
            )
        wife_id = fam["wife"]
        wife = individuals.get(wife_id)
        if wife and wife["sex"] != "F":
            errors.append(
                f"ERROR: FAMILY: US21: {fam_id}: WIFE {wife_id} "
                f"has SEX {wife['sex'] or 'NA'}, expected F"
            )
    return errors
